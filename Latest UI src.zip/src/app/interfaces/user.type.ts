export interface UserDetailsType {
    role: string;
    token: string;
    userId: string;
    userName: string
}